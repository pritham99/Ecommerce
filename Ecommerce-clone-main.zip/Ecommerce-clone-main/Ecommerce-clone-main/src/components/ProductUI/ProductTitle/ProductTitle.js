import React from "react";

const ProductTitle = (props) => {
	return <p className="product-title">{props.item.title}</p>;
};

export default ProductTitle;
