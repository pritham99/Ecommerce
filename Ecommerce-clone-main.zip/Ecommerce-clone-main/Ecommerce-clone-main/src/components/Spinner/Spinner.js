import React from "react";
import "./Spinner.css";

const spinner = () => <div className="loader"></div>;

export default spinner;
